<?php

$databaseHost = 'localhost';
$databaseName = 'db_akademik';
$databaseUsername = 'root';
$databasePassword = '';

$connection = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

?>