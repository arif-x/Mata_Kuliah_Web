<?php

$databaseHost = 'localhost';
$databaseName = 'db_upload_download';
$databaseUsername = 'root';
$databasePassword = '';

$connection = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

?>