<?php

$result = "SELECT * FROM upload";
$getFile = $connection->query($result);

?>