<?php

$databaseHost = 'localhost';
$databaseName = 'db_toko';
$databaseUsername = 'root';
$databasePassword = '';

$connection = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

?>