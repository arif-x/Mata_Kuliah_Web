<?php

  include 'tambah.php';
  include 'kurang.php';
  include 'kali.php';
  include 'bagi.php';
  include 'modulus.php';

?>