<?php

$result = "SELECT * FROM guestbook;";
$getGuestbook = $connection->query($result);

?>